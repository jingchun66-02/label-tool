import torch
from transformers import OwlViTProcessor, OwlViTForObjectDetection
from PIL import Image
import logging

# Suppress warnings
logging.getLogger("transformers").setLevel(logging.ERROR)

class Labeler:
    def __init__(self, model_name="google/owlvit-base-patch32", threshold=0.1):
        self.device = "cuda" if torch.cuda.is_available() else "mps" if torch.backends.mps.is_available() else "cpu"
        print(f"Using device: {self.device}")
        
        try:
            self.processor = OwlViTProcessor.from_pretrained(model_name)
            self.model = OwlViTForObjectDetection.from_pretrained(model_name).to(self.device)
            self.model.eval()
        except Exception as e:
            raise RuntimeError(f"Failed to load model {model_name}: {e}")
            
        self.threshold = threshold

    def detect(self, image_path, texts):
        """
        Detect objects in the image based on text descriptions.
        
        Args:
            image_path (str): Path to the image file.
            texts (list): List of text descriptions (e.g. ["cat", "dog"]).
            
        Returns:
            list: List of dictionaries containing label, score, and box [x_min, y_min, x_max, y_max].
        """
        try:
            image = Image.open(image_path).convert("RGB")
        except Exception as e:
            print(f"Error opening image {image_path}: {e}")
            return []
            
        # OWL-ViT expects text queries as a list of lists if batching, but here we process one image with multiple queries
        # The processor expects `text` to be a list of strings for a single image if we want to query multiple things.
        # Actually, for OwlViT, we usually pass nested lists if we have batch of images, but for single image:
        # inputs = processor(text=[texts], images=image, return_tensors="pt")
        
        inputs = self.processor(text=[texts], images=image, return_tensors="pt").to(self.device)
        
        with torch.no_grad():
            outputs = self.model(**inputs)
            
        # Target image sizes (height, width) to rescale box predictions [batch_size, 2]
        target_sizes = torch.Tensor([image.size[::-1]]).to(self.device)
        
        # Convert outputs (bounding boxes and class logits) to COCO API
        results = self.processor.image_processor.post_process_object_detection(outputs=outputs, target_sizes=target_sizes, threshold=self.threshold)
        
        # We only processed one image
        result = results[0]
        
        detections = []
        width, height = image.size
        
        for score, label_idx, box in zip(result["scores"], result["labels"], result["boxes"]):
            box = [round(i, 2) for i in box.tolist()]
            label = texts[label_idx]
            
            detections.append({
                "label": label,
                "score": round(score.item(), 4),
                "box": box,  # [xmin, ymin, xmax, ymax]
            })
            
        return {"size": [width, height], "detections": detections}
