import json
import os
from pathlib import Path

def export_results(results, output_dir, format='json', classes=None):
    """
    Export results to the specified format.
    
    Args:
        results (list): List of dictionaries containing image info and detections.
        output_dir (Path): Output directory.
        format (str): 'json' or 'yolo'.
        classes (list): List of class names (required for YOLO).
    """
    output_dir = Path(output_dir)
    
    if format == 'json':
        output_file = output_dir / 'labels.json'
        # If file exists and we are appending (not implemented here, we overwrite or load existing?)
        # For simplicity, we just write the whole list. 
        # But if we call this iteratively, it's bad for JSON.
        # CLI calls it once at the end for JSON.
        
        with open(output_file, 'w') as f:
            json.dump(results, f, indent=2)
            
    elif format == 'yolo':
        if classes is None:
            raise ValueError("Classes list required for YOLO export")
            
        class_map = {name: i for i, name in enumerate(classes)}
        
        for entry in results:
            image_name = Path(entry['image_name']).stem
            txt_path = output_dir / f"{image_name}.txt"
            
            img_w = entry['width']
            img_h = entry['height']
            
            with open(txt_path, 'w') as f:
                for det in entry['detections']:
                    label = det['label']
                    if label not in class_map:
                        continue
                    class_id = class_map[label]
                    
                    # Box is [xmin, ymin, xmax, ymax]
                    box = det['box']
                    xmin, ymin, xmax, ymax = box
                    
                    # Convert to center_x, center_y, w, h
                    w = xmax - xmin
                    h = ymax - ymin
                    cx = xmin + w / 2
                    cy = ymin + h / 2
                    
                    # Normalize
                    ncx = cx / img_w
                    ncy = cy / img_h
                    nw = w / img_w
                    nh = h / img_h
                    
                    # Clamp to 0-1 just in case
                    ncx = max(0, min(1, ncx))
                    ncy = max(0, min(1, ncy))
                    nw = max(0, min(1, nw))
                    nh = max(0, min(1, nh))
                    
                    f.write(f"{class_id} {ncx:.6f} {ncy:.6f} {nw:.6f} {nh:.6f}\n")
        
        # Write classes.txt
        with open(output_dir / 'classes.txt', 'w') as f:
            for c in classes:
                f.write(f"{c}\n")
