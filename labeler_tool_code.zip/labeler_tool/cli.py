import click
import os
from pathlib import Path
from .detector import Labeler
from .exporter import export_results

@click.command()
@click.option('--input', '-i', required=True, type=click.Path(exists=True), help='Input image file or directory')
@click.option('--prompts', '-p', required=True, help='Comma-separated list of text descriptions to label (e.g., "cat, dog, person")')
@click.option('--output', '-o', default='output', type=click.Path(), help='Output directory for the dataset')
@click.option('--threshold', '-t', default=0.1, type=float, help='Confidence threshold for detection (0.0 to 1.0)')
@click.option('--format', '-f', default='json', type=click.Choice(['json', 'yolo']), help='Output format')
def main(input, prompts, output, threshold, format):
    """
    Auto-label images using natural language descriptions.
    """
    click.echo(f"Starting labeling process...")
    click.echo(f"Input: {input}")
    click.echo(f"Prompts: {prompts}")
    
    # Parse prompts
    prompt_list = [p.strip() for p in prompts.split(',')]
    
    # Initialize detector
    click.echo("Loading model... (this may take a while first time)")
    labeler = Labeler(threshold=threshold)
    
    # Collect images
    input_path = Path(input)
    images = []
    if input_path.is_file():
        if input_path.suffix.lower() in ['.jpg', '.jpeg', '.png', '.bmp', '.webp']:
            images.append(input_path)
    else:
        for ext in ['*.jpg', '*.jpeg', '*.png', '*.bmp', '*.webp']:
            images.extend(list(input_path.glob(ext)))
            images.extend(list(input_path.glob(ext.upper())))
            
    if not images:
        click.echo("No images found!", err=True)
        return

    click.echo(f"Found {len(images)} images.")
    
    # Create output directory
    output_path = Path(output)
    output_path.mkdir(parents=True, exist_ok=True)
    
    # Process images
    results = []
    with click.progressbar(images, label='Labeling images') as bar:
        for img_path in bar:
            try:
                result = labeler.detect(str(img_path), prompt_list)
                if result and result['detections']:
                    # Add image info
                    entry = {
                        'image_path': str(img_path),
                        'image_name': img_path.name,
                        'width': result['size'][0],
                        'height': result['size'][1],
                        'detections': result['detections']
                    }
                    results.append(entry)
                    
                    # Export individual result if needed (e.g. for YOLO which is per file)
                    if format == 'yolo':
                        export_results([entry], output_path, format=format, classes=prompt_list)
                        
            except Exception as e:
                click.echo(f"\nError processing {img_path}: {e}", err=True)
    
    # Export combined results (for JSON)
    if format == 'json':
        export_results(results, output_path, format=format, classes=prompt_list)
        
    click.echo(f"Done! Results saved to {output}")

if __name__ == '__main__':
    main()
